from kivy.core.window import Window
Window.size = (400, 700)
from kivy.uix.screenmanager import Screen, ScreenManager


class Root(ScreenManager):
    def __init__(self, **kwargs):
        super(Root, self).__init__(**kwargs)
        Window.bind(on_keyboard=self._key_handler)
        self.screen_list = list()  # this list have all screen that user switched

    def _key_handler(self, instance, key, *args):

        if key is 27:
            # in Desktop this key 27 is Esc and in Phone it's Back btn
            self.previous_screen()
            return True

    def previous_screen(self):
        """
        Switch to previous screen last screen in screen_list
        """
        last_screen = self.screen_list.pop()
        if last_screen == "start":
            exit()
        print(self.screen_list)
        self.transition.direction = "left"
        self.current = self.screen_list[len(self.screen_list) - 1]

    def change_screen(self, name):
        """
        Switch Screen using screen name and
        """
        self.current = name
        if name not in self.screen_list:
            self.screen_list.append(self.current)
        else:
            self.screen_list.remove(name)
            self.screen_list.append(self.current)

        print(self.screen_list)

