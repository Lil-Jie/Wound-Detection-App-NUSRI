from kivymd.app import MDApp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.screen import MDScreen
from kivy.core.window import Window
from kivy.uix.scrollview import ScrollView
Window.size = (400, 700)
from opencv_analysis.opencv_analysis import edge_detect



class ManualPage(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def show_again(self):
        self.ids.init_img_2.source = "appimage/wound_image/input_wound/0.png"
        self.ids.init_img_2.reload()

    def result_show(self):
        file_path = "appimage/wound_image/input_wound/0.png"
        # min = str(int(self.ids.min_slider.value))
        max = int(self.ids.max_slider.value)
        edge_detect(file=file_path, minval=max/6, maxval=max)
        self.ids.result_img_2.source = r"appimage\wound_image\manual_result\manual_result.png"
        self.ids.result_img_2.reload()

class ManualpageApp(MDApp):

    def build(self):
        return ManualPage()


if __name__ == '__main__':
    ManualpageApp().run()
