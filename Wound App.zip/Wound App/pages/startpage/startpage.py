from kivymd.app import MDApp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.screen import MDScreen
from kivy.core.window import Window
from kivymd.uix.gridlayout import MDGridLayout
Window.size = (400, 700)


class StartPage(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class StartpageApp(MDApp):

    def build(self):
        return StartPage()


if __name__ == '__main__':
    StartpageApp().run()
