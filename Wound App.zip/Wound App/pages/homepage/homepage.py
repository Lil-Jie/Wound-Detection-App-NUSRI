import os
import cv2

from kivymd.app import MDApp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivymd.uix.screen import MDScreen
from kivymd.uix.taptargetview import MDTapTargetView
from kivymd.uix.tab import MDTabsBase
from kivymd.uix.swiper import MDSwiper
from kivy.core.window import Window
Window.size = (400, 700)
# Window.size = (360, 740)

from kivy.properties import ObjectProperty
from kivy.uix.popup import Popup
from kivy.factory import Factory
from kivymd.uix.snackbar import Snackbar
from kivymd.uix.snackbar import BaseSnackbar

from tf_analysis.tf_analysis import post_analysis
from word_file.word import word_file
from db.sqlite3_connect import insert_data, select_data, create_table


class SaveDialog(FloatLayout):
    save = ObjectProperty(None)
    cancel = ObjectProperty(None)


Factory.register('SaveDialog', cls=SaveDialog)


class HomePage(MDScreen, BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.event_loop_worker = None

    def dismiss_popup(self):
        # 关闭弹窗
        self._popup.dismiss()

    def show_save(self):
        # 绑定保存和取消的方法
        content = SaveDialog(save=self.save, cancel=self.dismiss_popup)
        self._popup = Popup(title="Upload file", content=content, size_hint=(0.9, 0.9))
        # 打开窗口
        self._popup.open()

    def save(self, path, filename):
        from asyncio_task.asyncio_insert_data import EventLoopWorker
        file_path = os.path.join(path, filename)
        self.ids.path_show.text = file_path
        new_img = cv2.imread(file_path)
        cv2.imwrite("appimage/wound_image/input_wound/0.png", new_img)
        Snackbar(
            text="File path is: [u]%s[/u]" % file_path,
            snackbar_x="10dp",
            snackbar_y="10dp",
            size_hint_x=.9
        ).open()
        self.event_loop_worker = worker = EventLoopWorker(file_path)
        worker.start()

        self.dismiss_popup()

    def show_upload(self):
        file = self.ids.path_show.text
        self.ids.init_img.source = "%s" % file

    def show_result(self):
        file = 'appimage/wound_image/input_wound'
        post_analysis(file)
        self.ids.result_img.source = 'appimage/wound_image/output_wound/result.png'
        self.ids.result_img.reload()

    def generate_report(self):
        name = self.ids.name_input.text
        gender = self.ids.gender_input.text
        age = self.ids.age_input.text
        height = self.ids.height_input.text
        weight = self.ids.weight_input.text
        sql = "UPDATE report SET name='" + name + "',gender='" + gender + "',age='" + str(
            age) + "',height='" + height + "',weight='" + weight + "' WHERE id = 1"
        print(sql)
        insert_data(sql)

        # Generate report
        str_img = r'appimage\wound_image\wound_label\wound_resize\resize.png'
        word_file(file=str_img)
        Snackbar(
            text="The report has already been generated!",
            snackbar_x="10dp",
            snackbar_y="10dp",
            size_hint_x=.9
        ).open()

    def refresh(self):
        self.ids.name_input.text = ''
        self.ids.age_input.text = ''
        self.ids.gender_input.text = ''
        self.ids.height_input.text = ''
        self.ids.weight_input.text = ''
        Snackbar(
            text="Personal information has been cleared !",
            snackbar_x="10dp",
            snackbar_y="10dp",
            size_hint_x=.9
        ).open()


class HomepageApp(MDApp):

    def callback(self, instance):
        print(instance.icon)

    def build(self):
        return HomePage()

    def on_tab_switch(self, instance_tabs, instance_tab, instance_tab_label):
        pass


if __name__ == '__main__':
    HomepageApp().run()
