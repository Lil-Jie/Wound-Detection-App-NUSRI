from kivymd.app import MDApp
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.screen import MDScreen
from kivy.core.window import Window
from kivy.uix.scrollview import ScrollView
Window.size = (400, 700)


class SignupPage(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class SignuppageApp(MDApp):

    def build(self):
        return SignupPage()


if __name__ == '__main__':
    SignuppageApp().run()
