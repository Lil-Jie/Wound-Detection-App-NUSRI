from kivy.uix.boxlayout import BoxLayout
from kivymd.uix.textfield import MDTextField


class OneLineTextDialog(BoxLayout):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def input_text(self):
        return self.ids.dialog_text.text
