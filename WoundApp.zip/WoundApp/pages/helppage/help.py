from kivy.app import App
from custom_gestures.gesture_box import GestureBox

from kivy.core.window import Window
Window.size = (475, 650)


class HelpPage(GestureBox):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.ids.help_box_label_note.text = '''
Instructions for use:
1.Enter Homepage
2.Upload wound image file
3.Press the 'Reload' button to confirm the wound image
4.Press the 'Analysis' button to analysis wound and display
5.Input personal information
6.Press the 'Generate Report' button to generate medical report



Thanks for Prof.Fuh Ying Hsi's guidance.
This project is designed by Liu Youjie-NUS.
If you have any questions, please contact the relevant person.

        '''

    @staticmethod
    def help_to_info():
        App.get_running_app().screen_manager.transition.direction = 'right'
        App.get_running_app().screen_manager.current = "Info"


class HelpApp(App):
    def build(self):
        return HelpPage()


if __name__ == "__main__":
    HelpApp().run()
