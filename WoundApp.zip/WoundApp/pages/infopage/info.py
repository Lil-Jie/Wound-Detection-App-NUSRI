import os

from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image

from custom_gestures import gesture_nd as gesture
from db.sqlite3_connect import insert_data, select_data, create_table

class ImageButton(ButtonBehavior, Image):
    """使用图片按钮"""
    pass


class InfoPage(gesture.GestureBox):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        sql = 'SELECT * FROM personal_setting WHERE id=1'
        res = select_data(sql)
        self.ids.slide_name_label.text = res[0][1]

    @staticmethod
    def home_slide_button():
        App.get_running_app().screen_manager.transition.direction = 'left'
        App.get_running_app().screen_manager.current = 'Home'

    @staticmethod
    def me_slide_button():
        App.get_running_app().screen_manager.current = 'Me'

    @staticmethod
    def doctor_slide_button():
        App.get_running_app().screen_manager.current = 'Doctor'

    @staticmethod
    def help_slide_button():
        App.get_running_app().screen_manager.current = 'Help'
