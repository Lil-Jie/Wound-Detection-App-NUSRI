import os

from kivy.app import App
from kivy.uix.tabbedpanel import TabbedPanel
from kivy.uix.floatlayout import FloatLayout
from kivy.core.window import Window
from kivy.properties import ObjectProperty
from kivy.uix.popup import Popup
from kivy.factory import Factory

from db.sqlite3_connect import insert_data, select_data, create_table
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image

from analyse.analyse import edge_detect
from word_file.word import word_file

Window.size = (475, 650)


class ImageButton(ButtonBehavior, Image):
    """使用图片按钮"""
    pass


class SaveDialog(FloatLayout):
    save = ObjectProperty(None)
    cancel = ObjectProperty(None)


Factory.register('SaveDialog', cls=SaveDialog)


class HomePage(TabbedPanel):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.event_loop_worker = None

    def dismiss_popup(self):
        # 关闭弹窗
        self._popup.dismiss()

    def show_save(self):
        # 绑定保存和取消的方法
        content = SaveDialog(save=self.save, cancel=self.dismiss_popup)
        self._popup = Popup(title="Upload file", content=content, size_hint=(0.9, 0.9))
        # 打开窗口
        self._popup.open()

    def save(self, path, filename):
        from asyncio_task.asyncio_insert_data import EventLoopWorker
        file_path = os.path.join(path, filename)
        self.ids.status.text = file_path
        self.event_loop_worker = worker = EventLoopWorker(file_path)
        self.ids.upload_tip.text = "[size=20]Upload has started, please do not upload again!!!\nThe address is as follow:[/size]"
        worker.start()

        self.dismiss_popup()

    def show_upload(self):
        file = self.ids.status.text
        self.ids.init.source = "%s" % file

    def show_result(self):
        edge_detect(file=self.ids.status.text)
        self.ids.init.source = "output_image/result.jpg"
        # 根据不同文件保留相应存储结果
        # img = self.ids.status.text
        # self.ids.init.source = "%s" % img + "_result.jpg"

    def generate_report(self):
        name = self.ids.name_input.text
        gender = self.ids.gender_input.text
        age = self.ids.age_input.text
        height = self.ids.height_input.text
        weight = self.ids.weight_input.text
        sql = "UPDATE patients SET name='" + name + "',gender='" + gender + "',age='" + str(
            age) + "',height='" + height + "',weight='" + weight + "' WHERE id = 1"
        print(sql)
        insert_data(sql)

        # Generate report
        word_file(file=self.ids.status.text)

    @staticmethod
    def home_to_info():
        App.get_running_app().screen_manager.transition.direction = 'right'
        App.get_running_app().screen_manager.current = 'Info'


class HomeApp(App):
    def build(self):
        return HomePage()


if __name__ == '__main__':
    from kivy.core.window import Window
    Window.clearcolor = [.8, .8, .8, 1]
    HomeApp().run()
