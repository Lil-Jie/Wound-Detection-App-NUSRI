import os

from kivy.app import App
from kivy.uix.floatlayout import FloatLayout
from kivy.properties import ObjectProperty
from kivy.uix.popup import Popup

from db.sqlite3_connect import insert_data, select_data, create_table
from custom_gestures.gesture_box import GestureBox

from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image


class ImageButton(ButtonBehavior, Image):
    """使用图片按钮"""
    pass


class SaveImageDialog(FloatLayout):
    save = ObjectProperty(None)
    cancel = ObjectProperty(None)


class ResetDialog(FloatLayout):
    save = ObjectProperty(None)
    cancel = ObjectProperty(None)


class MePage(GestureBox):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        sql = 'SELECT * FROM personal_setting WHERE id=1'
        res = select_data(sql)
        self.ids.name_input.text = res[0][1]
        self.ids.gender_input.text = res[0][2]
        self.ids.age_input.text = res[0][3]
        self.head_path = res[0][4]
        self.ids.test_image_box.canvas.after.children[2].source = self.head_path

    def dismiss_popup(self):
        """关闭弹窗"""
        self._popup.dismiss()

    def save_head_image(self, path, filename):
        """保存头像路径"""
        self.head_path = os.path.join(path, filename)
        self.ids.test_image_box.canvas.after.children[2].source = self.head_path
        self.dismiss_popup()

    @staticmethod
    def write_image_to_head(file_path):
        """将图片写入头像图片中"""
        with open(file_path, "rb") as f:
            file_data = f.read()
            with open('background/head.png', 'wb') as w:
                w.write(file_data)

    def show_head_image(self):
        """点击头像回调方法"""
        content = SaveImageDialog(save=self.save_head_image, cancel=self.dismiss_popup)
        self._popup = Popup(title="Upload image", content=content, size_hint=(0.9, 0.9))
        self._popup.open()

    def save_all_changes(self):
        """保存修改"""
        name = self.ids.name_input.text
        gender = self.ids.gender_input.text
        age = self.ids.age_input.text
        sql = "UPDATE personal_setting SET name='"+name+"',gender='"+gender+"',age='"+str(age)+"',head_image='"+self.head_path+"' WHERE id = 1"
        print(sql)
        insert_data(sql)

        # 改变头像
        self.write_image_to_head(self.head_path)

        self.clear_widgets()
        self.__init__()
        self.set_change_value()
        self.return_info_button()

    def return_info_button(self):
        """返回主页"""
        self.clear_widgets()
        self.__init__()
        App.get_running_app().screen_manager.transition.direction = 'right'
        App.get_running_app().screen_manager.current = 'Info'

    def set_change_value(self):
        """设置改变的值"""
        # info页面
        info = App.get_running_app().screen_manager.get_screen('Info')
        # name
        info.children[0].ids.slide_name_label.text = self.ids.name_input.text
        # head
        info.children[0].ids.head_image_box.canvas.after.children[2].source = self.head_path

