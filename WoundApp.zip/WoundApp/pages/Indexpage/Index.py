from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.core.window import Window

Window.size = (475, 650)


class IndexPage(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def index_to_home():
        App.get_running_app().screen_manager.current = "Info"


class IndexApp(App):
    def build(self):
        return IndexPage()


if __name__ == "__main__":
    IndexApp().run()
