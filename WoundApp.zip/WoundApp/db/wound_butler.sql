--
-- ��SQLiteStudio v3.2.1 �������ļ� �ܶ� 4�� 6 20:00:34 2021
--
-- �ı����룺GBK
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- ����patients
CREATE TABLE patients (
    id        INTEGER      PRIMARY KEY,
    name      VARCHAR (20) UNIQUE,
    gender    VARCHAR,
    age       VARCHAR,
    height    VARCHAR,
    weight    VARCHAR,
    area      VARCHAR,
    perimeter VARCHAR
);

INSERT INTO patients (id, name, gender, age, height, weight, area, perimeter) VALUES (1, 'Yang Boxiang', 'Male', '15', '18', '18', NULL, NULL);

-- ����personal_setting
CREATE TABLE personal_setting (
    id         INTEGER       PRIMARY KEY,
    name       VARCHAR (20)  NOT NULL
                             UNIQUE,
    gender     VARCHAR (20)  NOT NULL,
    age        VARCHAR,
    head_image VARCHAR (200) NOT NULL
);

INSERT INTO personal_setting (id, name, gender, age, head_image) VALUES (1, 'LLL', 'Male', '21', 'D:\PythonProject\WoundApp\background\dog.jpg');

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
