from kivy.app import App
from kivy.uix.screenmanager import Screen, ScreenManager

# Load pages
from pages.Indexpage.Index import IndexPage
from pages.homepage.home import HomePage
from pages.infopage.info import InfoPage
from pages.helppage.help import HelpPage
from pages.mepage.me import MePage


class MyApp(App):
    def build(self):
        self.icon = "background/ckt.jpg"
        # Load kv files
        self.load_kv("pages/Indexpage/Index.kv")
        self.load_kv("pages/homepage/home.kv")
        self.load_kv("pages/infopage/info.kv")
        self.load_kv("pages/helppage/help.kv")
        self.load_kv("pages/mepage/me.kv")
        self.screen_manager = ScreenManager()
        pages = {'Index': IndexPage(), 'Home': HomePage(), 'Info': InfoPage(), 'Help': HelpPage(), 'Me': MePage()}
        for item, page in pages.items():
            self.default_page = page
            screen = Screen(name=item)
            # Add pages
            screen.add_widget(self.default_page)
            # Add pages to the screen manager
            self.screen_manager.add_widget(screen)
        return self.screen_manager


if __name__ == "__main__":
    recite_app = MyApp()
    # Set title
    recite_app.title = 'Wound Butler'
    recite_app.run()
